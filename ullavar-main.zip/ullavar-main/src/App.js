import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, NavLink } from 'react-router-dom';
import { FaLeaf,FaUser, FaEnvelope, FaSeedling, FaTools, FaIdCard, FaHandshake, FaTractor, FaImage, FaMapMarkerAlt, FaCalendarAlt, FaCheckCircle, FaUserFriends, FaPhone, FaFileAlt, FaShoppingCart, FaClipboardList, FaBriefcase } from 'react-icons/fa';
import { MdOutlineConstruction, MdSettings, MdSell, MdLandscape } from 'react-icons/md';
import { BsArrowRightCircle, BsCalendarCheck, BsStars } from 'react-icons/bs';
import './App.css';
import {
  GiWheat,
  GiFarmTractor,
  GiPlantRoots,
  GiFruitTree,
  GiWateringCan,
} from 'react-icons/gi';
import { GiWoodenFence } from 'react-icons/gi';
import fencingImg from './assert/fencing.jpg';
import mango from './assert/Mango AMC.jpg';
import water from './assert/Water Tank Construction.jpg';
import drip from './assert/Drip Irrigation.webp';
import coconut from './assert/Coconut Plantation.jpg';
import farm from './assert/Farm Shed Construction.jpg';
import worker from './assert/farm workers.jpg'
import farmhouseImg from './assert/FArmhouse.jpeg'
import poolImg from './assert/Swimmingpool.jpeg'
import tankImg from './assert/tank.jpeg'
import polyhouseImg from './assert/polly.jpeg'
import shedImg from './assert/goat.jpg'

// Mock Data
const projects = [
  {
    id: 1,
    title: "Fencing Project",
    description: "2.5 Acres – Done in 3 Days",
    location: "Erode",
    image: fencingImg,
    category: "fencing"
  },
  { 
    id: 2,
    title: "Mango AMC",
    description: "600 Trees – April Cycle",
    location: "Salem",
    image: mango,
    category: "amc"
  },
  {
    id: 3,
    title: "Water Tank Construction",
    description: "15,000 Litre – Built in 7 Days",
    location: "Coimbatore",
    image: water,
    category: "construction"
  },
  {
    id: 4,
    title: "Drip Irrigation Setup",
    description: "5 Acres – Completed in 5 Days",
    location: "Madurai",
    image: drip,
    category: "irrigation"
  },
  {
    id: 5,
    title: "Coconut Plantation",
    description: "200 Trees – Planted in 2 Days",
    location: "Tirupur",
    image: coconut,
    category: "planting"
  },
  {
    id: 6,
    title: "Farm Shed Construction",
    description: "1000 sq.ft – Built in 15 Days",
    location: "Pollachi",
    image: farm,
    category: "construction"
  }
];


const services = [
  {
    title: "AMC (Annual Maintenance Contract)",
    icon: <FaCalendarAlt className="service-icon" />,
    description: "Scheduled maintenance for your farm with calendar-based tracking"
  },
  {
    title: "New Projects",
    icon: <MdOutlineConstruction className="service-icon" />,
    description: "Fencing, drip irrigation, planting and more"
  },
  {
    title: "Construction",
    icon: <GiWoodenFence className="service-icon" />,
    description: "Tanks, pools, sheds and other farm structures"
  },
  {
    title: "Inputs Supply",
    icon: <FaShoppingCart className="service-icon" />,
    description: "Tools, fertilizers, motors and other farm inputs"
  },
  {
    title: "Land Buy/Sell",
    icon: <MdLandscape className="service-icon" />,
    description: "Verified listings with soil/water data"
  },
  {
    title: "Crop Sales",
    icon: <MdSell className="service-icon" />,
    description: "Buyer connect and market price comparison"
  }
];

const trustFactors = [
  {
    title: "Photo Proof for Every Task",
    icon: <FaImage />,
    description: "Visual verification of completed work"
  },
  {
    title: "Calendar-Based AMC",
    icon: <FaCalendarAlt />,
    description: "Structured, not ad-hoc maintenance"
  },
  {
    title: "Fertilizer + Weather Synced",
    icon: <GiWateringCan />,
    description: "Smart scheduling based on conditions"
  },
  {
    title: "Transparent Pricing",
    icon: <FaHandshake />,
    description: "No hidden fees, no middlemen"
  },
  {
    title: "Easy Approval Process",
    icon: <FaCheckCircle />,
    description: "Via app or WhatsApp"
  },
  {
    title: "Trained Local Teams",
    icon: <FaUserFriends />,
    description: "Verified contracts and reliable workers"
  },
  {
    title: "One Vendor Responsibility",
    icon: <FaBriefcase />,
    description: "Single point of contact for all work"
  }
];

const howItWorks = [
  {
    step: 1,
    title: "Farm Visit & Needs Mapping",
    description: "We visit your farm and document requirements",
    icon: <FaMapMarkerAlt />
  },
  {
    step: 2,
    title: "Quote + Calendar",
    description: "We provide transparent pricing and schedule",
    icon: <FaCalendarAlt />
  },
  {
    step: 3,
    title: "Contract & Team Assignment",
    description: "Sign agreement and we assign the right team",
    icon: <FaFileAlt />
  },
  {
    step: 4,
    title: "Work & Photo Upload",
    description: "Work execution with photo documentation",
    icon: <FaImage />
  },
  {
    step: 5,
    title: "Approval by Farmer",
    description: "Review and approve completed tasks",
    icon: <FaCheckCircle />
  },
  {
    step: 6,
    title: "Monthly Reports",
    description: "Detailed reporting of all work done",
    icon: <FaClipboardList />
  }
];

function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % projects.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Router>
      <div className="app">
        <nav className="navbar">
          <div className="navbar-container">
            <div className="logo">
              <GiWheat className="logo-icon" />
              <span className="logo-text">Ullavar Connect</span>
            </div>
            <div className={`menu-toggle ${isMenuOpen ? 'open' : ''}`} onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <span></span>
              <span></span>
              <span></span>
            </div>
            <ul className={`nav-menu ${isMenuOpen ? 'open' : ''}`}>
              <li><NavLink to="/" end onClick={() => setIsMenuOpen(false)}>Home</NavLink></li>
              <li><NavLink to="/about" onClick={() => setIsMenuOpen(false)}>About</NavLink></li>
              <li><NavLink to="/manage-farm" onClick={() => setIsMenuOpen(false)}>Manage Farm</NavLink></li>
              <li><NavLink to="/buy-inputs" onClick={() => setIsMenuOpen(false)}>Buy Inputs</NavLink></li>
              <li><NavLink to="/sell-produce" onClick={() => setIsMenuOpen(false)}>Sell Produce</NavLink></li>
              <li><NavLink to="/land" onClick={() => setIsMenuOpen(false)}>Land</NavLink></li>
              <li><NavLink to="/construction" onClick={() => setIsMenuOpen(false)}>Construction</NavLink></li>
              <li><NavLink to="/projects" onClick={() => setIsMenuOpen(false)}>Past Work</NavLink></li>
              <li><NavLink to="/join" onClick={() => setIsMenuOpen(false)}>Join Us</NavLink></li>
            </ul>
          </div>
        </nav>

        <main>
          <Routes>
            <Route path="/" element={<HomePage currentSlide={currentSlide} />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/manage-farm" element={<ManageFarmPage />} />
            <Route path="/buy-inputs" element={<BuyInputsPage />} />
            <Route path="/sell-produce" element={<SellProducePage />} />
            <Route path="/land" element={<LandPage />} />
            <Route path="/construction" element={<ConstructionPage />} />
            <Route path="/projects" element={<ProjectsPage />} />
            <Route path="/join" element={<JoinUsPage />} />
          </Routes>
        </main>

        <footer className="footer">
          <div className="footer-container">
            <div className="footer-content">
              <div className="footer-section">
                <h3>Ullavar Connect</h3>
                <p>Manage Your Farm Like a Pro. From Soil to Sale.</p>
              </div>
              <div className="footer-section">
                <h3>Quick Links</h3>
                <ul>
                  <li><Link to="/about">About Us</Link></li>
                  <li><Link to="/contact">Contact</Link></li>
                  <li><Link to="/faqs">FAQs</Link></li>
                  <li><Link to="/privacy-policy">Privacy Policy</Link></li>
                  <li><Link to="/careers">Careers</Link></li>
                </ul>
              </div>
              <div className="footer-section">
  <h3>Contact Us</h3>
  <p>Email: uzhavarconnect2025@gmail.com</p>
  <p>Phone: +91 7550119994 / 9842297056</p>

  <div className="app-download">
    <h4>Address</h4>
    <div className="app-buttons">
      <p>
        7/3, Duraiswamy Nagar<br />
        Coimbatore, Tamil Nadu - 641014<br />
        India
      </p>
    </div>
  </div>
</div>
            </div>
            <div className="footer-cta">
              <h2>Start with a One-Time Project or Choose a Monthly Plan</h2>
              <div className="cta-buttons">
                <button className="btn btn-primary">Book Now</button>
                <button className="btn btn-secondary">Talk to Our Team</button>
              </div>
            </div>
            <div className="footer-bottom">
              <p>&copy; {new Date().getFullYear()} Ullavar Connect. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

function HomePage({ currentSlide }) {
  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="hero-content">
          <h1>Manage Your Farm Like a Pro. From Soil to Sale.</h1>
          <p>AMC, planting, irrigation, fencing, inputs, tank work, harvesting, buyer connect – all in one app. With photo proof.</p>
          <div className="hero-cta">
            <button className="btn btn-primary"><GiFarmTractor /> Start Managing My Farm</button>
            <button className="btn btn-secondary"><FaCalendarAlt /> Book a Project</button>
            <button className="btn btn-secondary"><FaShoppingCart /> Buy Agri Inputs</button>
            <button className="btn btn-secondary"><MdSell /> Sell My Produce</button>
          </div>
        </div>
        <div className="hero-image">
          <img src="https://images.unsplash.com/photo-1500937386664-56d1dfef3854?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" alt="Farm Management" />
        </div>
      </section>

      <section className="what-we-do-section">
        <div className="section-heading">
          <h2><FaLeaf /> We Are Ullavar Connect – What We Do</h2>
          <p className="tagline">We are not a consultancy. Not just labour. We are your farm's execution team – structured, documented, scheduled.</p>
        </div>
        <div className="services-grid">
          {services.map((service, index) => (
            <div className="service-card" key={index}>
              <div className="service-card-icon">
                {service.icon}
              </div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </div>
          ))}
        </div>
        <button className="btn btn-primary center-btn">Explore All Services <BsArrowRightCircle /></button>
      </section>

      <section className="trust-section">
        <div className="section-heading">
          <h2><BsStars /> Why Farmers Choose Us</h2>
        </div>
        <div className="trust-factors">
          {trustFactors.map((factor, index) => (
            <div className="trust-card" key={index}>
              <div className="trust-icon">{factor.icon}</div>
              <h3>{factor.title}</h3>
              <p>{factor.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="how-it-works-section">
        <div className="section-heading">
          <h2><MdSettings /> How It Works – SOP System</h2>
        </div>
        <div className="steps-container">
          {howItWorks.map((step) => (
            <div className="step-card" key={step.step}>
              <div className="step-number">{step.step}</div>
              <div className="step-icon">{step.icon}</div>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
        <button className="btn btn-primary center-btn">Book Site Visit <BsArrowRightCircle /></button>
      </section>

      <section className="recent-projects-section">
        <div className="section-heading">
          <h2><FaImage /> Recent Projects</h2>
        </div>
        <div className="projects-carousel">
          <div className="carousel-container" style={{ transform: `translateX(-${currentSlide * 100}%)` }}>
            {projects.map((project, index) => (
              <div className="project-card" key={project.id}>
                <div className="project-image">
                  <img src={project.image} alt={project.title} />
                </div>
                <div className="project-info">
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <p className="project-location"><FaMapMarkerAlt /> {project.location}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="carousel-dots">
          {projects.map((_, index) => (
            <span 
              key={index} 
              className={`dot ${currentSlide === index ? 'active' : ''}`} 
            />
          ))}
        </div>
        <Link to="/projects" className="btn btn-primary center-btn">See Past Work <BsArrowRightCircle /></Link>
      </section>
    </div>
  );
}

function AboutPage() {
  return (
    <div className="about-page">
      <section className="about-hero">
        <div className="about-hero-content">
          <h1>Who We Are</h1>
          <div className="about-statement">
            <p>We are Ullavar Connect – a full-stack, no-nonsense, execution team for farmers.</p>
            <p className="highlight">We've built farms. Not decks.</p>
            <p className="highlight">We don't sell leads. We take responsibility.</p>
          </div>
        </div>
        <div className="about-hero-image">
          <img src="https://media.istockphoto.com/id/1316735334/photo/young-indian-farmer-with-agronomist-at-banana-field.jpg?s=612x612&w=0&k=20&c=SjD-Bi-oO9LsYUSB69Jphal7nB-DySGiwLb8aDnw8UI=" alt="Farm Workers" />
        </div>
      </section>
      
      <section className="about-mission">
        <h2>Our Mission</h2>
        <p>Whether you're a 10-acre landowner or NRI, we offer peace of mind, proof of work, and professional systems.</p>
        <blockquote>Build your farm like it's a factory.</blockquote>
      </section>
      
      <section className="about-team">
        <h2>Our Team</h2>
        <div className="team-grid">
          <div className="team-member">
            <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Team Member" />
            <h3>Ramesh Kumar</h3>
            <p>Founder & Agricultural Expert</p>
          </div>
          <div className="team-member">
            <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Team Member" />
            <h3>Priya Sharma</h3>
            <p>Operations Director</p>
          </div>
          <div className="team-member">
            <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Team Member" />
            <h3>Vijay Reddy</h3>
            <p>Technical Lead</p>
          </div>
        </div>
      </section>
    </div>
  );
}

function ManageFarmPage() {
  const [activeTab, setActiveTab] = useState('monthly');
  
  return (
    <div className="manage-farm-page">
      <section className="page-header">
        <h1><GiFarmTractor /> Manage My Farm</h1>
        <p>For AMC (maintenance) and Projects</p>
      </section>
      
      <div className="farm-tabs">
        <div className="tab-headers">
          <button 
            className={`tab-btn ${activeTab === 'monthly' ? 'active' : ''}`}
            onClick={() => setActiveTab('monthly')}
          >
            <BsCalendarCheck /> Monthly AMC
          </button>
          <button 
            className={`tab-btn ${activeTab === 'fertilizer' ? 'active' : ''}`}
            onClick={() => setActiveTab('fertilizer')}
          >
            <GiPlantRoots /> Fertilizer Plan
          </button>
          <button 
            className={`tab-btn ${activeTab === 'pruning' ? 'active' : ''}`}
            onClick={() => setActiveTab('pruning')}
          >
            <FaSeedling /> Pruning & Pest Control
          </button>
          <button 
            className={`tab-btn ${activeTab === 'project' ? 'active' : ''}`}
            onClick={() => setActiveTab('project')}
          >
            <MdOutlineConstruction /> Project Work
          </button>
          <button 
            className={`tab-btn ${activeTab === 'construction' ? 'active' : ''}`}
            onClick={() => setActiveTab('construction')}
          >
            <GiWoodenFence /> Construction
          </button>
          <button 
            className={`tab-btn ${activeTab === 'reports' ? 'active' : ''}`}
            onClick={() => setActiveTab('reports')}
          >
            <FaClipboardList /> Reports & Approval
          </button>
        </div>
        
        <div className="tab-content">
          {activeTab === 'monthly' && (
            <div className="tab-pane">
              <h2>Monthly AMC (Annual Maintenance Contract)</h2>
              <p>Our structured monthly maintenance plans keep your farm in optimal condition year-round.</p>
              <div className="plan-cards">
                <div className="plan-card">
                  <h3>Basic Plan</h3>
                  <ul>
                    <li>Monthly farm visit</li>
                    <li>Basic irrigation check</li>
                    <li>Pest monitoring</li>
                    <li>Monthly report</li>
                  </ul>
                  <button className="btn btn-primary">Select Plan</button>
                </div>
                <div className="plan-card featured">
                  <div className="featured-badge">Popular</div>
                  <h3>Standard Plan</h3>
                  <ul>
                    <li>Bi-weekly farm visit</li>
                    <li>Full irrigation maintenance</li>
                    <li>Pest control application</li>
                    <li>Fertilizer application</li>
                    <li>Detailed bi-weekly reports</li>
                  </ul>
                  <button className="btn btn-primary">Select Plan</button>
                </div>
                <div className="plan-card">
                  <h3>Premium Plan</h3>
                  <ul>
                    <li>Weekly farm visit</li>
                    <li>Complete farm management</li>
                    <li>Advanced pest management</li>
                    <li>Customized fertilizer program</li>
                    <li>Weekly detailed reports</li>
                    <li>Priority support</li>
                  </ul>
                  <button className="btn btn-primary">Select Plan</button>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'fertilizer' && (
            <div className="tab-pane">
              <h2>Fertilizer Plan</h2>
              <p>Custom fertilizer scheduling based on crop needs and seasonal conditions.</p>
              <div className="fertilizer-content">
                <div className="fertilizer-image">
                  <img src="https://images.unsplash.com/photo-1563514227147-6d2ff665a7a4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Fertilizer Application" />
                </div>
                <div className="fertilizer-info">
                  <h3>Weather-Synced Fertilizer Application</h3>
                  <p>Our system automatically adjusts your fertilizer schedule based on weather forecasts and soil conditions.</p>
                  <ul>
                    <li>Soil testing and analysis</li>
                    <li>Custom nutrient programs</li>
                    <li>Seasonal adjustments</li>
                    <li>Organic and conventional options</li>
                  </ul>
                  <button className="btn btn-primary">Schedule Soil Test</button>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'pruning' && (
            <div className="tab-pane">
              <h2>Pruning & Pest Control</h2>
              <p>Maintain healthy growth and protect your crops from pests.</p>
              <div className="service-details">
                <div className="service-image">
                  <img src="https://images.unsplash.com/photo-1627646295764-3fb77cbd2d1f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Pruning Service" />
                </div>
                <div className="service-text">
                  <h3>Expert Pruning Services</h3>
                  <p>Our trained teams use proper techniques to encourage healthy growth and maximum yield.</p>
                  <ul>
                    <li>Seasonal maintenance pruning</li>
                    <li>Structural pruning for young trees</li>
                    <li>Rejuvenation pruning for older plants</li>
                    <li>Post-harvest pruning</li>
                  </ul>
                </div>
              </div>
              <div className="service-details reversed">
                <div className="service-text">
                  <h3>Integrated Pest Management</h3>
                  <p>Environmentally sensitive approach to pest control with minimal chemical use.</p>
                  <ul>
                    <li>Regular monitoring and early detection</li>
                    <li>Biological control methods</li>
                    <li>Targeted application when necessary</li>
                    <li>Detailed pest tracking and reports</li>
                  </ul>
                </div>
                <div className="service-image">
                  <img src="https://images.unsplash.com/photo-1620735692151-16a2679bbce7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Pest Control" />
                </div>
              </div>
              <button className="btn btn-primary center-btn">Schedule Service</button>
            </div>
          )}
          
          {activeTab === 'project' && (
            <div className="tab-pane">
              <h2>Project Work</h2>
              <p>Professional implementation of farm development projects.</p>
              <div className="projects-grid">
                <div className="project-item">
                  <div className="project-icon"><GiWoodenFence/></div>
                  <h3>Fencing Solutions</h3>
                  <p>Secure your farm with durable fencing options.</p>
                  <button className="btn btn-secondary">Get Quote</button>
                </div>
                <div className="project-item">
                  <div className="project-icon"><GiWateringCan /></div>
                  <h3>Drip Irrigation</h3>
                  <p>Water-efficient irrigation systems custom designed.</p>
                  <button className="btn btn-secondary">Get Quote</button>
                </div>
                <div className="project-item">
                  <div className="project-icon"><GiFruitTree /></div>
                  <h3>Plantation Projects</h3>
                  <p>Complete planting service with quality saplings.</p>
                  <button className="btn btn-secondary">Get Quote</button>
                </div>
                <div className="project-item">
                  <div className="project-icon"><FaTractor /></div>
                  <h3>Land Preparation</h3>
                  <p>Soil preparation and land development services.</p>
                  <button className="btn btn-secondary">Get Quote</button>
                </div>
              </div>
              <div className="project-cta">
                <h3>Have a custom project in mind?</h3>
                <button className="btn btn-primary">Request Custom Quote</button>
              </div>
            </div>
          )}
          
          {activeTab === 'construction' && (
            <div className="tab-pane">
              <h2>Construction Services</h2>
              <p>Build essential farm infrastructure with our experienced construction teams.</p>
              <div className="construction-items">
                <div className="construction-item">
                  <img src="https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Water Tank" />
                  <h3>Water Tanks</h3>
                  <p>Storage solutions for irrigation needs.</p>
                </div>
                <div className="construction-item">
                  <img src="https://images.unsplash.com/photo-1513828742140-ccaa28f3eda6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Farm Shed" />
                  <h3>Storage Sheds</h3>
                  <p>Protect equipment and harvest.</p>
                </div>
                <div className="construction-item">
                  <img src="https://images.unsplash.com/photo-1564501049412-61c2a3083791?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Farmhouse" />
                  <h3>Farmhouses</h3>
                  <p>Comfortable on-farm living spaces.</p>
                </div>
              </div>
              <Link to="/construction" className="btn btn-primary center-btn">View All Construction Services</Link>
            </div>
          )}
          
          {activeTab === 'reports' && (
            <div className="tab-pane">
              <h2>Reports & Approval Logs</h2>
              <p>Track all farm activities with detailed documentation.</p>
              <div className="reports-demo">
                <div className="reports-image">
                  <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Reports Dashboard" />
                </div>
                <div className="reports-features">
                  <h3>Our Reporting System Includes:</h3>
                  <ul>
                    <li>Photo documentation of all work</li>
                    <li>Task completion timestamps</li>
                    <li>Worker performance metrics</li>
                    <li>Material usage tracking</li>
                    <li>Weather condition logs</li>
                    <li>Digital approval systems</li>
                    <li>Monthly summary reports</li>
                  </ul>
                  <button className="btn btn-primary">View Sample Report</button>
                </div>
              </div>
              <div className="approval-system">
                <h3>Easy Approval System</h3>
                <p>Review and approve work through our app or WhatsApp messages.</p>
                <div className="approval-demo">
                  <div className="approval-step">
                    <div className="step-number">1</div>
                    <p>Receive notification of completed work</p>
                  </div>
                  <div className="approval-step">
                    <div className="step-number">2</div>
                    <p>View photos and details</p>
                  </div>
                  <div className="approval-step">
                    <div className="step-number">3</div>
                    <p>Approve or request changes</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="farm-cta">
        <div className="cta-buttons">
          <button className="btn btn-primary">Start AMC</button>
          <button className="btn btn-secondary">Book Project</button>
          <button className="btn btn-secondary">Upload My Farm Details</button>
        </div>
      </div>
    </div>
  );
}

function BuyInputsPage() {
  return (
    <div className="buy-inputs-page">
      <section className="page-header">
        <h1><FaShoppingCart /> Buy Agri Inputs – Ullavar Mart</h1>
        <div className="phase-badge">Phase 2 – Under Construction</div>
      </section>
      
      <div className="coming-soon">
        <div className="coming-soon-content">
          <h2>Coming Soon!</h2>
          <p>We're building a comprehensive marketplace for all your agricultural input needs.</p>
          <div className="features-preview">
            <div className="feature">
              <FaShoppingCart className="feature-icon" />
              <p>Buy fertilizers, pesticides, motors, tools</p>
            </div>
            <div className="feature">
              <FaCheckCircle className="feature-icon" />
              <p>Verified brands with farmer reviews</p>
            </div>
            <div className="feature">
              <FaTractor className="feature-icon" />
              <p>Bulk pricing + delivery</p>
            </div>
            <div className="feature">
              <FaCalendarAlt className="feature-icon" />
              <p>AMC-linked auto refill</p>
            </div>
          </div>
          <button className="btn btn-primary">Get Notified When Ready</button>
        </div>
        <div className="coming-soon-image">
          <img src="https://media.gettyimages.com/id/1318237749/photo/female-farm-worker-using-digital-tablet-with-virtual-reality-artificial-intelligence-for.jpg?s=612x612&w=gi&k=20&c=TB5tXFr1kM7uWWKkHuv8ZtDyd-hDBQnaSvBeTXZ-77A=" alt="Agricultural Supplies" />
        </div>
      </div>
    </div>
  );
}

function SellProducePage() {
  return (
    <div className="sell-produce-page">
      <section className="page-header">
        <h1><MdSell /> Sell My Produce – Ullavar Bazaar</h1>
        <div className="phase-badge">Phase 2 – Under Construction</div>
      </section>
      
      <div className="coming-soon">
        <div className="coming-soon-image">
          <img src="https://img.freepik.com/premium-photo/indian-vegetable-market-seller-with-lush-fresh-produce_1174497-154470.jpg" alt="Farm Fresh Produce" />
        </div>
        <div className="coming-soon-content">
          <h2>Coming Soon!</h2>
          <p>We're creating a marketplace to connect farmers directly with buyers.</p>
          <div className="features-preview">
            <div className="feature">
              <FaImage className="feature-icon" />
              <p>Upload crop photos</p>
            </div>
            <div className="feature">
              <FaHandshake className="feature-icon" />
              <p>Grading & Buyer Matching</p>
            </div>
            <div className="feature">
              <FaClipboardList className="feature-icon" />
              <p>Market Price Comparison</p>
            </div>
            <div className="feature">
              <FaCheckCircle className="feature-icon" />
              <p>Instant Payment Status</p>
            </div>
            <div className="feature">
              <FaFileAlt className="feature-icon" />
              <p>APEDA / FPC / Invoice help</p>
            </div>
          </div>
          <button className="btn btn-primary">Get Notified When Ready</button>
        </div>
      </div>
    </div>
  );
}

function LandPage() {
  return (
    <div className="land-page">
      <section className="page-header">
        <h1><MdLandscape /> Buy/Sell Land – Ullavar Bhoomi</h1>
        <div className="phase-badge">Phase 2 – Under Construction</div>
      </section>
      
      <div className="coming-soon">
        <div className="coming-soon-content">
          <h2>Coming Soon!</h2>
          <p>A verified marketplace for agricultural land with detailed farming suitability information.</p>
          <div className="features-preview">
            <div className="feature">
              <FaCheckCircle className="feature-icon" />
              <p>Verified listings with soil/water data</p>
            </div>
            <div className="feature">
              <FaFileAlt className="feature-icon" />
              <p>Legal & boundary checks</p>
            </div>
            <div className="feature">
              <FaClipboardList className="feature-icon" />
              <p>Cultivation-readiness reports</p>
            </div>
            <div className="feature">
              <FaHandshake className="feature-icon" />
              <p>Buyer-seller match</p>
            </div>
          </div>
          <button className="btn btn-primary">Get Notified When Ready</button>
        </div>
        <div className="coming-soon-image">
          <img src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Agricultural Land" />
        </div>
      </div>
    </div>
  );
}

function ConstructionPage() {
  return (
    <div className="construction-page">
      <section className="page-header">
        <h1><MdOutlineConstruction /> Construction Services</h1>
        <p>Quality infrastructure for your farm with professional teams</p>
      </section>
      
      <section className="construction-intro">
        <div className="intro-content">
          <h2>Farm Infrastructure Experts</h2>
          <p>From water storage to living spaces, we build the facilities your farm needs to thrive.</p>
          <p>All our construction projects come with:</p>
          <ul>
            <li>Detailed planning and estimation</li>
            <li>Quality materials</li>
            <li>Professional construction teams</li>
            <li>Regular progress updates</li>
            <li>Photo documentation</li>
            <li>Transparent billing</li>
          </ul>
          <button className="btn btn-primary">Request Quote</button>
        </div>
        <div className="intro-image">
          <img src="https://images.unsplash.com/photo-1531834685032-c34bf0d84c77?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Farm Construction" />
        </div>
      </section>
      
      <section className="construction-services">
        <h2>Our Construction Services</h2>
        <div className="service-cards">
          <div className="service-card">
        <img src={farmhouseImg} alt="Farmhouse" />
        <h3>Farmhouses</h3>
        <p>Elegant farm living with modern comforts.</p>
        <p>Perfect for retreats or permanent residence.</p>
        <button className="btn btn-secondary">Get Quote</button>
      </div>

      <div className="service-card">
        <img src={poolImg} alt="Swimming Pool" />
        <h3>Swimming Pools</h3>
        <p>Luxury pools designed for relaxation & fun.</p>
        <p>Durable, stylish, and low-maintenance.</p>
        <button className="btn btn-secondary">Get Quote</button>
      </div>

      <div className="service-card">
        <img src={tankImg} alt="Water Tanks" />
        <h3>Water Tanks</h3>
        <p>Reliable storage for irrigation & livestock.</p>
        <p>Built strong, lasting through all seasons.</p>
        <button className="btn btn-secondary">Get Quote</button>
      </div>

      <div className="service-card">
        <img src={fencingImg} alt="Fencing" />
        <h3>Fencing</h3>
        <p>Secure & durable fencing solutions.</p>
        <p>Protect crops, livestock, and property.</p>
        <button className="btn btn-secondary">Get Quote</button>
      </div>

      <div className="service-card">
        <img src={polyhouseImg} alt="Polyhouse" />
        <h3>Polyhouse</h3>
        <p>Climate-controlled farming spaces.</p>
        <p>Boosts yield with advanced technology.</p>
        <button className="btn btn-secondary">Get Quote</button>
      </div>

      <div className="service-card">
        <img src={shedImg} alt="Cow & Goat Shed" />
        <h3>Cow & Goat Sheds</h3>
        <p>Hygienic, ventilated, and durable shelters.</p>
        <p>Designed for animal comfort & health.</p>
        <button className="btn btn-secondary">Get Quote</button>
      </div>
        </div>
      </section>
      
      <section className="construction-cta">
        <h2>Ready to Start Your Construction Project?</h2>
        <div className="cta-buttons">
          <button className="btn btn-primary">Request Quote</button>
          <button className="btn btn-secondary">See Past Constructions</button>
        </div>
      </section>
    </div>
  );
}

function ProjectsPage() {
  const [filter, setFilter] = useState('all');
  
  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.category === filter);
  
  return (
    <div className="projects-page">
      <section className="page-header">
        <h1><FaImage /> Past Work – Project Gallery</h1>
        <p>Explore our completed projects across Tamil Nadu</p>
      </section>
      
      <div className="projects-filter">
        <button 
          className={`filter-btn ${filter === 'all' ? 'active' : ''}`} 
          onClick={() => setFilter('all')}
        >
          All Projects
        </button>
        <button 
          className={`filter-btn ${filter === 'fencing' ? 'active' : ''}`} 
          onClick={() => setFilter('fencing')}
        >
          <GiWoodenFence /> Fencing
        </button>
        <button 
          className={`filter-btn ${filter === 'planting' ? 'active' : ''}`} 
          onClick={() => setFilter('planting')}
        >
          <GiFruitTree /> Planting
        </button>
        <button 
          className={`filter-btn ${filter === 'construction' ? 'active' : ''}`} 
          onClick={() => setFilter('construction')}
        >
          <MdOutlineConstruction /> Construction
        </button>
        <button 
          className={`filter-btn ${filter === 'irrigation' ? 'active' : ''}`} 
          onClick={() => setFilter('irrigation')}
        >
          <GiWateringCan /> Irrigation
        </button>
        <button 
          className={`filter-btn ${filter === 'amc' ? 'active' : ''}`} 
          onClick={() => setFilter('amc')}
        >
          <FaCalendarAlt /> AMC
        </button>
      </div>
      
      <div className="projects-grid">
        {filteredProjects.map(project => (
          <div className="gallery-project-card" key={project.id}>
            <div className="project-image">
              <img src={project.image} alt={project.title} />
            </div>
            <div className="project-info">
              <h3>{project.title}</h3>
              <p>{project.description}</p>
              <p className="project-location"><FaMapMarkerAlt /> {project.location}</p>
              <div className="project-rating">
                <span className="star">★</span>
                <span className="star">★</span>
                <span className="star">★</span>
                <span className="star">★</span>
                <span className="star">★</span>
                <span className="rating-text">5.0</span>
              </div>
              <button className="btn btn-secondary">See Project Detail</button>
            </div>
          </div>
        ))}
      </div>
      
      <div className="projects-pagination">
        <button className="pagination-btn active">1</button>
        <button className="pagination-btn">2</button>
        <button className="pagination-btn">3</button>
        <button className="pagination-btn">Next →</button>
      </div>
    </div>
  );
}
function JoinUsPage() {
  const [userType, setUserType] = useState('');
  const [formData, setFormData] = useState({
    // Common fields
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    
    // Farmer specific
    farmName: '',
    farmSize: '',
    cropTypes: '',
    farmingExperience: '',
    irrigationType: '',
    currentChallenges: '',
    
    // Worker/Contractor specific
    workerType: '',
    experience: '',
    skills: '',
    vehicleOwned: '',
    availability: '',
    previousWork: '',
    idProof: '',
    expectedSalary: ''
  });

  const [errors, setErrors] = useState({});

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    // Common validations
    if (!formData.fullName.trim()) newErrors.fullName = 'Full name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
    if (!formData.address.trim()) newErrors.address = 'Address is required';
    if (!formData.city.trim()) newErrors.city = 'City is required';
    if (!formData.state.trim()) newErrors.state = 'State is required';
    if (!formData.pincode.trim()) newErrors.pincode = 'Pincode is required';
    
    // Email validation
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }
    
    // Phone validation
    if (formData.phone && !/^\d{10}$/.test(formData.phone)) {
      newErrors.phone = 'Please enter a valid 10-digit phone number';
    }
    
    if (userType === 'farmer') {
      if (!formData.farmName.trim()) newErrors.farmName = 'Farm name is required';
      if (!formData.farmSize.trim()) newErrors.farmSize = 'Farm size is required';
      if (!formData.cropTypes.trim()) newErrors.cropTypes = 'Crop types are required';
      if (!formData.farmingExperience.trim()) newErrors.farmingExperience = 'Farming experience is required';
    } else if (userType === 'worker') {
      if (!formData.workerType.trim()) newErrors.workerType = 'Worker type is required';
      if (!formData.experience.trim()) newErrors.experience = 'Experience is required';
      if (!formData.skills.trim()) newErrors.skills = 'Skills are required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      console.log('Form submitted:', { userType, ...formData });
      alert(`Registration submitted successfully for ${userType}!`);
      // Here you would typically send data to your backend
    }
  };

  const resetForm = () => {
    setUserType('');
    setFormData({
      fullName: '', email: '', phone: '', address: '', city: '', state: '', pincode: '',
      farmName: '', farmSize: '', cropTypes: '', farmingExperience: '', irrigationType: '', currentChallenges: '',
      workerType: '', experience: '', skills: '', vehicleOwned: '', availability: '', previousWork: '', idProof: '', expectedSalary: ''
    });
    setErrors({});
  };

  if (!userType) {
    return (
      <div className="join-us-page">
        <section className="page-header">
          <h1><FaUserFriends /> Join Ullavar Connect</h1>
          <p>Choose your registration type to get started</p>
        </section>
        
        <div className="join-sections">
          <div className="join-section farmers">
            <div className="join-content">
              <h2><FaSeedling /> Register as Farmer</h2>
              <p>Connect with agricultural services and grow your farming business</p>
              <ul style={{textAlign: 'left', margin: '20px 0'}}>
                <li>Get customized farming solutions</li>
                <li>Access to modern agricultural techniques</li>
                <li>Direct connection with service providers</li>
                <li>Track progress via app or WhatsApp</li>
              </ul>
              <button 
                className="btn btn-primary" 
                onClick={() => setUserType('farmer')}
              >
                Register as Farmer
              </button>
            </div>
            <div className="join-image">
              <img src="https://media.istockphoto.com/id/1330214199/photo/indian-farmer-busy-using-mobile-phone-while-sitting-in-between-the-crop-seedlings-inside.jpg?s=612x612&w=0&k=20&c=PmGOwjZlQdOhETmjVwBoT4thL3mJn3VfEm5q9doj4aU=" alt="Farmer Using App" />
            </div>
          </div>
          
          <div className="join-section workers">
            <div className="join-image">
              <img src="https://pub-b47a7c74540d40228598178154fb4b56.r2.dev/2023/10/Azure-OpenAI-Service-India-blog-hero.jpg" alt="Farm Workers" />
            </div>
            <div className="join-content">
              <h2><FaTools /> Register as Worker/Contractor</h2>
              <p>Join our network of skilled agricultural professionals</p>
              <ul style={{textAlign: 'left', margin: '20px 0'}}>
                <li>Weekly payments for completed work</li>
                <li>Performance-based job opportunities</li>
                <li>Training and skill development</li>
                <li>Flexible working arrangements</li>
              </ul>
              <button 
                className="btn btn-primary" 
                onClick={() => setUserType('worker')}
              >
                Register as Worker/Contractor
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="join-us-page">
      <section className="page-header">
        <h1>
          {userType === 'farmer' ? <FaSeedling /> : <FaTools />}
          {userType === 'farmer' ? 'Farmer Registration' : 'Worker/Contractor Registration'}
        </h1>
        <p>Please fill out all required information</p>
        <button 
          onClick={resetForm}
          style={{
            background: 'none',
            border: '1px solid #ccc',
            padding: '8px 16px',
            borderRadius: '4px',
            cursor: 'pointer',
            marginTop: '10px'
          }}
        >
          ← Change Registration Type
        </button>
      </section>

      <div className="join-sections">
        <div className="join-section" style={{flexDirection: 'column', maxWidth: '800px', margin: '0 auto'}}>
          <div className="registration-form">
            
            {/* Personal Information Section */}
            <div className="form-section">
              <h3><FaUser /> Personal Information</h3>
              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="fullName">Full Name *</label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    className={errors.fullName ? 'error' : ''}
                    placeholder="Enter your full name"
                  />
                  {errors.fullName && <span className="error-message">{errors.fullName}</span>}
                </div>
                <div className="form-group">
                  <label htmlFor="email">Email Address *</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className={errors.email ? 'error' : ''}
                    placeholder="Enter your email"
                  />
                  {errors.email && <span className="error-message">{errors.email}</span>}
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="phone">Phone Number *</label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className={errors.phone ? 'error' : ''}
                    placeholder="10-digit mobile number"
                    maxLength="10"
                  />
                  {errors.phone && <span className="error-message">{errors.phone}</span>}
                </div>
                <div className="form-group">
                  <label htmlFor="pincode">Pincode *</label>
                  <input
                    type="text"
                    id="pincode"
                    name="pincode"
                    value={formData.pincode}
                    onChange={handleInputChange}
                    className={errors.pincode ? 'error' : ''}
                    placeholder="Enter pincode"
                    maxLength="6"
                  />
                  {errors.pincode && <span className="error-message">{errors.pincode}</span>}
                </div>
              </div>
            </div>

            {/* Address Information Section */}
            <div className="form-section">
              <h3><FaMapMarkerAlt /> Address Information</h3>
              <div className="form-group">
                <label htmlFor="address">Full Address *</label>
                <textarea
                  id="address"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  className={errors.address ? 'error' : ''}
                  placeholder="Enter your complete address"
                  rows="3"
                />
                {errors.address && <span className="error-message">{errors.address}</span>}
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="city">City *</label>
                  <input
                    type="text"
                    id="city"
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    className={errors.city ? 'error' : ''}
                    placeholder="Enter city"
                  />
                  {errors.city && <span className="error-message">{errors.city}</span>}
                </div>
                <div className="form-group">
                  <label htmlFor="state">State *</label>
                  <select
                    id="state"
                    name="state"
                    value={formData.state}
                    onChange={handleInputChange}
                    className={errors.state ? 'error' : ''}
                  >
                    <option value="">Select State</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Telangana">Telangana</option>
                    <option value="Other">Other</option>
                  </select>
                  {errors.state && <span className="error-message">{errors.state}</span>}
                </div>
              </div>
            </div>

            {/* Farmer Specific Fields */}
            {userType === 'farmer' && (
              <div className="form-section">
                <h3><FaSeedling /> Farm Information</h3>
                <div className="form-row">
                  <div className="form-group">
  
                  
                  </div>
                  <div className="form-group">
                    <label htmlFor="farmSize">Farm Size (in acres) *</label>
                    <input
                      type="text"
                      id="farmSize"
                      name="farmSize"
                      value={formData.farmSize}
                      onChange={handleInputChange}
                      className={errors.farmSize ? 'error' : ''}
                      placeholder="e.g., 5 acres"
                    />
                    {errors.farmSize && <span className="error-message">{errors.farmSize}</span>}
                  </div>
                </div>
                
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="cropTypes">Primary Crops *</label>
                    <input
                      type="text"
                      id="cropTypes"
                      name="cropTypes"
                      value={formData.cropTypes}
                      onChange={handleInputChange}
                      className={errors.cropTypes ? 'error' : ''}
                      placeholder="e.g., Empty, Coconut, Mango"
                    />
                    {errors.cropTypes && <span className="error-message">{errors.cropTypes}</span>}
                  </div>
                  <div className="form-group">
                    <label htmlFor="farmingExperience">Farming Experience *</label>
                    <select
                      id="farmingExperience"
                      name="farmingExperience"
                      value={formData.farmingExperience}
                      onChange={handleInputChange}
                      className={errors.farmingExperience ? 'error' : ''}
                    >
                      <option value="">Select Experience</option>
                      <option value="0-2 years">0-2 years</option>
                      <option value="3-5 years">3-5 years</option>
                      <option value="6-10 years">6-10 years</option>
                      <option value="10+ years">10+ years</option>
                    </select>
                    {errors.farmingExperience && <span className="error-message">{errors.farmingExperience}</span>}
                  </div>
                </div>
                
                
                
                <div className="form-group">
                  <label htmlFor="currentChallenges">Current Farming Challenges</label>
                  <textarea
                    id="currentChallenges"
                    name="currentChallenges"
                    value={formData.currentChallenges}
                    onChange={handleInputChange}
                    placeholder="Describe any current challenges you face in farming"
                    rows="3"
                  />
                </div>
              </div>
            )}

            {/* Worker/Contractor Specific Fields */}
            {userType === 'worker' && (
              <div className="form-section">
                <h3><FaTools /> Professional Information</h3>
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="workerType">Worker Type *</label>
                    <select
                      id="workerType"
                      name="workerType"
                      value={formData.workerType}
                      onChange={handleInputChange}
                      className={errors.workerType ? 'error' : ''}
                    >
                      <option value="">Select Worker Type</option>
                      <option value="Sprayer">Sprayer</option>
                      <option value="Fencer">Fencer</option>
                      <option value="Driver">Driver</option>
                      <option value="Tractor Operator">Tractor Operator</option>
                      <option value="Harvesting Contractor">Harvesting Contractor</option>
                      <option value="General Farm Worker">General Farm Worker</option>
                      <option value="Irrigation Specialist">Irrigation Specialist</option>
                      <option value="Other">Other</option>
                    </select>
                    {errors.workerType && <span className="error-message">{errors.workerType}</span>}
                  </div>
                  <div className="form-group">
                    <label htmlFor="experience">Experience *</label>
                    <select
                      id="experience"
                      name="experience"
                      value={formData.experience}
                      onChange={handleInputChange}
                      className={errors.experience ? 'error' : ''}
                    >
                      <option value="">Select Experience</option>
                      <option value="0-1 years">0-1 years</option>
                      <option value="1-3 years">1-3 years</option>
                      <option value="3-5 years">3-5 years</option>
                      <option value="5-10 years">5-10 years</option>
                      <option value="10+ years">10+ years</option>
                    </select>
                    {errors.experience && <span className="error-message">{errors.experience}</span>}
                  </div>
                </div>
                
                <div className="form-group">
                  <label htmlFor="skills">Skills & Expertise *</label>
                  <textarea
                    id="skills"
                    name="skills"
                    value={formData.skills}
                    onChange={handleInputChange}
                    className={errors.skills ? 'error' : ''}
                    placeholder="Describe your skills and areas of expertise"
                    rows="3"
                  />
                  {errors.skills && <span className="error-message">{errors.skills}</span>}
                </div>
                
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="vehicleOwned">Vehicle Owned</label>
                    <select
                      id="vehicleOwned"
                      name="vehicleOwned"
                      value={formData.vehicleOwned}
                      onChange={handleInputChange}
                    >
                      <option value="">Select Vehicle</option>
                      <option value="Two Wheeler">Two Wheeler</option>
                      <option value="Three Wheeler">Three Wheeler</option>
                      <option value="Four Wheeler">Four Wheeler</option>
                      <option value="Tractor">Tractor</option>
                      <option value="None">None</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label htmlFor="availability">Availability</label>
                    <select
                      id="availability"
                      name="availability"
                      value={formData.availability}
                      onChange={handleInputChange}
                    >
                      <option value="">Select Availability</option>
                      <option value="Full Time">Full Time</option>
                      <option value="Part Time">Part Time</option>
                      <option value="Seasonal">Seasonal</option>
                      <option value="Weekend Only">Weekend Only</option>
                    </select>
                  </div>
                </div>
                
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="expectedSalary">Expected Daily Rate (₹)</label>
                    <input
                      type="number"
                      id="expectedSalary"
                      name="expectedSalary"
                      value={formData.expectedSalary}
                      onChange={handleInputChange}
                      placeholder="Enter expected daily rate"
                      min="0"
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="idProof">ID Proof Type</label>
                    <select
                      id="idProof"
                      name="idProof"
                      value={formData.idProof}
                      onChange={handleInputChange}
                    >
                      <option value="">Select ID Proof</option>
                      <option value="Aadhaar Card">Aadhaar Card</option>
                      <option value="Driving License">Driving License</option>
                      <option value="Voter ID">Voter ID</option>
                      <option value="PAN Card">PAN Card</option>
                      <option value="Passport">Passport</option>
                    </select>
                  </div>
                </div>
                
                <div className="form-group">
                  <label htmlFor="previousWork">Previous Work Experience</label>
                  <textarea
                    id="previousWork"
                    name="previousWork"
                    value={formData.previousWork}
                    onChange={handleInputChange}
                    placeholder="Describe your previous work experience in agriculture"
                    rows="3"
                  />
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="form-section">
              <button type="button" onClick={handleSubmit} className="btn btn-primary" style={{width: '100%', padding: '15px', fontSize: '18px'}}>
                {userType === 'farmer' ? 'Register My Farm' : 'Apply as Partner'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}


export default App;